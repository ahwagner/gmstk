import os

HOME = os.environ['HOME']
USER = 'awagner'
LINUSNAME = 'linus202'